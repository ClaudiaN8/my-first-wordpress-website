   
            
            </div>
            <div class="footer bg-light border-top">
            <?php 
            include('template-parts/footer/footer-widgets.php');
            include('template-parts/footer/site-info.php'); 
            wp_footer(); 
            ?> 
            </div>
    </body>
</html>