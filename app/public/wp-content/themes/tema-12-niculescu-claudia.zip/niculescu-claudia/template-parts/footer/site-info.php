
    <div class="footer text-center py-1">
        <?php echo '<a href=' . get_bloginfo('url') . '>' . get_bloginfo('name') . '</a>' . " " . date("Y"); ?> | Copyright &copy; All rights reserved.
    </div>

