<?php 
    dynamic_sidebar('footer-widgets');
?>