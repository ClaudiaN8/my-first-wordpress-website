
    <div class="footer text-center py-1">
        <?php echo bloginfo('name') . " " . date("Y"); ?> | Copyright &copy; All rights reserved.
    </div>

