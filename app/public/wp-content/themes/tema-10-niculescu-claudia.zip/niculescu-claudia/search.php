<?php 

get_header();

if ( have_posts() ) {
    ?>
    <h3>Search results for:</h3> <?php $_GET['s'];

    the_posts_pagination();

	while ( have_posts() ) {
		the_post(); 
         
        get_template_part( 'template-parts/post/content', 'excerpt');
    }
    the_posts_pagination();

} else {
    ?>
    <h3>No results!</h3>
    <h4>Try sometring else.</h4>

   <?php get_search_form(); ?>

<?php }

get_sidebar();

get_footer();

?>