<?php

if ( ! function_exists( 'theme_setup' ) ) {
		/**
		 * Sets up theme defaults and registers support for various WordPress features.
		 *
		 * Note that this function is hooked into the after_setup_theme hook, which runs
		 * before the init hook. The init hook is too late for some features, such as indicating
		 * support post thumbnails.
		 */
		function theme_setup() {
		 
		    /**
		     * Make theme available for translation.
		     * Translations can be placed in the /languages/ directory.
		     */
		    load_theme_textdomain( 'text_domain', get_template_directory() . '/languages' );
		 
		    /**
		     * Add default posts and comments RSS feed links to <head>.
		     */
		    add_theme_support( 'automatic-feed-links' );
		 
		    /**
		     * Enable support for post thumbnails and featured images.
		     */
		    add_theme_support( 'post-thumbnails' );
		 
		    /**
		     * Add support for two custom navigation menus.
		     */
		    register_nav_menus( array(
		        'primary'   => __( 'Primary Menu', 'text_domain' ),
		        'secondary' => __('Secondary Menu', 'text_domain' )
		    ) );
		 
		    /**
		     * Enable support for the following post formats:
		     * aside, gallery, quote, image, and video
		     */
		    add_theme_support( 'post-formats', array ( 'aside', 'gallery', 'quote', 'image', 'video' ) );
		}
} // theme_setup
add_action( 'after_setup_theme', 'theme_setup' );

function add_theme_scripts() {
    wp_enqueue_style( 'bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css');

    wp_enqueue_style( 'fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css');

    wp_enqueue_style( 'style', get_stylesheet_uri(), array('bootstrap'), filemtime( get_stylesheet_directory() .'/style.css' ));
    
    wp_enqueue_script( 'bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js', array ( 'jquery' ), 1.1, true);
    
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'add_theme_scripts' );



/**
 * Register Custom Navigation Walker
 */
function register_navwalker(){
	require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';
}
add_action( 'after_setup_theme', 'register_navwalker' );


/**
 * Adding Custom Logo support
 */

function themename_custom_logo_setup() {
    $defaults = array(
        'height'               => 100,
        'width'                => 400,
        'flex-height'          => true,
        'flex-width'           => true,
        'header-text'          => array( 'site-title', 'site-description' ),
        'unlink-homepage-logo' => true, 
    );
 
    add_theme_support( 'custom-logo', $defaults );
}
 
add_action( 'after_setup_theme', 'themename_custom_logo_setup' );


function my_awesome_sidebar() {
  $args = array(
    'name'          => 'Footer Widgets',
    'id'            => 'footer-widgets',
    'description'   => 'The Footer Widgets is shown on the bottom side of blog pages in this theme',
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<h2 class="widgettitle">',
    'after_title'   => '</h2>' 
  );

  register_sidebar( $args );
}

add_action( 'widgets_init', 'my_awesome_sidebar' );


