Acesta este un mesaj din Index.


<?php 

get_header();

get_sidebar();

get_footer();

?>

Nu sterg mesajele! Sa fie clar!