Ne scufundam in Footer.

<?php wp_footer(); ?>    
    </body>
</html>