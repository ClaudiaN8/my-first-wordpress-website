<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="style.css" />
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU"
            crossorigin="anonymous"
        />
        <title>Claudia Niculescu</title>
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">CN</a>
                <button
                    class="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                >
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div
                    class="collapse navbar-collapse"
                    id="navbarSupportedContent"
                >
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a
                                class="nav-link active"
                                aria-current="page"
                                href="index.php"
                                >Home</a
                            >
                        </li>
                        <li class="nav-item dropdown">
                            <a
                                class="nav-link dropdown-toggle"
                                href="#"
                                id="navbarDropdown"
                                role="button"
                                data-bs-toggle="dropdown"
                                aria-expanded="false"
                            >
                                Movies
                            </a>
                            <ul
                                class="dropdown-menu"
                                aria-labelledby="navbarDropdown"
                            >
                                <li>
                                    <a class="dropdown-item" href="movie-1.php"
                                        >Anne with an E</a
                                    >
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#"
                                        >Altered carbon</a
                                    >
                                </li>
                                <li><hr class="dropdown-divider" /></li>
                                <li>
                                    <a class="dropdown-item" href="movies.php"
                                        >All movies</a
                                    >
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>
                    </ul>
                    <form class="d-flex">
                        <input
                            class="form-control me-2"
                            type="search"
                            placeholder="Search"
                            aria-label="Search"
                        />
                        <button class="btn btn-outline-success" type="submit">
                            Search
                        </button>
                    </form>
                </div>
            </div>
        </nav>

        <div class="container">
            <h1>Altered carbon</h1>
            <div class="row">
                <div class="col-3">
                    <img
                        src="https://resizing.flixster.com/7b948xu-X_sRms81mbdeptbpphU=/206x305/v2/https://resizing.flixster.com/-O0zsK2XE6LhZusJQTS4FeQ4mpM=/ems.ZW1zLXByZC1hc3NldHMvdHZzZXJpZXMvUlRUVjI3OTE4NC53ZWJw"
                        alt="poster Altered carbon"
                    />
                </div>
                <div class="col-9">
                    <p><strong>2018</strong></p>
                    <p>
                        More than 300 years in the future, society has been
                        transformed by new technology, leading to human bodies
                        being interchangeable and death no longer being
                        permanent. Takeshi Kovacs is the only surviving soldier
                        of a group of elite interstellar warriors who were
                        defeated in an uprising against the new world order. His
                        mind was imprisoned for centuries until impossibly
                        wealthy businessman Laurens Bancroft offers him the
                        chance to live again. Kovacs will have to do something
                        for Bancroft, though, if he wants to be resurrected.
                        Bancroft's request of Kovacs is to solve a murder --
                        Bancroft's. "Altered Carbon" is based on Richard K.
                        Morgan's cyberpunk noir novel of the same name.
                    </p>
                    <p>
                        <strong>Executive producers: </strong>Laeta Kalogridis
                    </p>
                    <p><strong>Creator: </strong>Laeta Kalogridis</p>
                    <p><strong>Starring: </strong></p>
                    <ul>
                        <li>Anthony Mackie</li>
                        <li>Renee Elise Goldsberry</li>
                        <li>Lela Loren</li>
                        <li>Simone Missick</li>
                        <li>Chris Conner</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer">Copyright, toate drepturile rezervate</div>
        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ"
            crossorigin="anonymous"
        ></script>
    </body>
</html>
