<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="style.css" />
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU"
            crossorigin="anonymous"
        />
        <title>Claudia Niculescu</title>
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">CN</a>
                <button
                    class="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                >
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div
                    class="collapse navbar-collapse"
                    id="navbarSupportedContent"
                >
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a
                                class="nav-link active"
                                aria-current="page"
                                href="index.php"
                                >Home</a
                            >
                        </li>
                        <li class="nav-item dropdown">
                            <a
                                class="nav-link dropdown-toggle"
                                href="#"
                                id="navbarDropdown"
                                role="button"
                                data-bs-toggle="dropdown"
                                aria-expanded="false"
                            >
                                Movies
                            </a>
                            <ul
                                class="dropdown-menu"
                                aria-labelledby="navbarDropdown"
                            >
                                <li>
                                    <a class="dropdown-item" href="#"
                                        >Anne with an E</a
                                    >
                                </li>
                                <li>
                                    <a class="dropdown-item" href="movie-2.php"
                                        >Altered carbon</a
                                    >
                                </li>
                                <li><hr class="dropdown-divider" /></li>
                                <li>
                                    <a class="dropdown-item" href="movies.php"
                                        >All movies</a
                                    >
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>
                    </ul>
                    <form class="d-flex">
                        <input
                            class="form-control me-2"
                            type="search"
                            placeholder="Search"
                            aria-label="Search"
                        />
                        <button class="btn btn-outline-success" type="submit">
                            Search
                        </button>
                    </form>
                </div>
            </div>
        </nav>

        <div class="container">
            <h1>Anne with an E</h1>
            <div class="row">
                <div class="col-3">
                    <img
                        src="https://resizing.flixster.com/AW1iz42FgfL53STaBD2QRfHfBZc=/206x305/v2/https://resizing.flixster.com/RP1KKxlbEX5flfVjM6e8J3yHmqs=/ems.ZW1zLXByZC1hc3NldHMvdHZzZXJpZXMvUlRUVjI1Mzk5NS53ZWJw"
                        alt="poster Anne with an E"
                    />
                </div>
                <div class="col-9">
                    <p><strong>2017</strong></p>
                    <p>
                        This reimagining of the classic book and film is a
                        coming-of-age story about a young orphan who is seeking
                        love, acceptance and her place in the world. Amybeth
                        McNulty stars as Anne, a 13-year-old who has endured an
                        abusive childhood in orphanages and the homes of
                        strangers. In the late 1890s, Anne is mistakenly sent to
                        live with aging siblings, Marilla and Matthew Cuthbert,
                        who live on Prince Edward Island. Anne, who proves to be
                        uniquely spirited, imaginative and smart, transforms the
                        lives of Marilla, Matthew and everyone else in their
                        small town.
                    </p>
                    <p>
                        <strong>Executive producers: </strong>Miranda de Pencier
                        , Elizabeth Bradley , Alison Owen , Debra Hayward , Ken
                        Girotti
                    </p>
                    <p><strong>Creator: </strong>Moira Walley-Beckett</p>
                    <p><strong>Starring: </strong></p>
                    <ul>
                        <li>Amybeth McNulty</li>
                        <li>R.H. Thomson</li>
                        <li>Geraldine James</li>
                        <li>Lucas Jade Zumann</li>
                        <li>Dalila Bela</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer">Copyright, toate drepturile rezervate</div>
        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ"
            crossorigin="anonymous"
        ></script>
    </body>
</html>
