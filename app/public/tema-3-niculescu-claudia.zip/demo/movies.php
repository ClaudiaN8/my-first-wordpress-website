<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="style.css" />
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU"
            crossorigin="anonymous"
        />
        <title>Claudia Niculescu</title>
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.php">CN</a>
                <button
                    class="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                >
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div
                    class="collapse navbar-collapse"
                    id="navbarSupportedContent"
                >
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a
                                class="nav-link active"
                                aria-current="page"
                                href="index.php"
                                >Home</a
                            >
                        </li>
                        <li class="nav-item dropdown">
                            <a
                                class="nav-link dropdown-toggle"
                                href="#"
                                id="navbarDropdown"
                                role="button"
                                data-bs-toggle="dropdown"
                                aria-expanded="false"
                            >
                                Movies
                            </a>
                            <ul
                                class="dropdown-menu"
                                aria-labelledby="navbarDropdown"
                            >
                                <li>
                                    <a class="dropdown-item" href="movie-1.php"
                                        >Anne with an E</a
                                    >
                                </li>
                                <li>
                                    <a class="dropdown-item" href="movie-2.php"
                                        >White lines</a
                                    >
                                </li>
                                <li><hr class="dropdown-divider" /></li>
                                <li>
                                    <a class="dropdown-item" href="#"
                                        >All movies</a
                                    >
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>
                    </ul>
                    <form class="d-flex">
                        <input
                            class="form-control me-2"
                            type="search"
                            placeholder="Search"
                            aria-label="Search"
                        />
                        <button class="btn btn-outline-success" type="submit">
                            Search
                        </button>
                    </form>
                </div>
            </div>
        </nav>

        <div class="container">
            <h1>Movies</h1>
            <div class="row row-cols-3">

                <?php 
                $movies = array(
                    "movie1" => array(
                        "img_src" => "https://resizing.flixster.com/AW1iz42FgfL53STaBD2QRfHfBZc=/206x305/v2/https://resizing.flixster.com/RP1KKxlbEX5flfVjM6e8J3yHmqs=/ems.ZW1zLXByZC1hc3NldHMvdHZzZXJpZXMvUlRUVjI1Mzk5NS53ZWJw",
                        "img_alt" => "poster Anne with an E",
                        "title" => "ANNE WITH AN E",
                        "desc" => "This reimagining of the classic book and film is a
                        coming-of-age story about a young orphan who is
                        seeking love, acceptance and her place in the world",
                        "permalink" => "movie-1.php",

                    ),
                    "movie2" => array(
                        "img_src" => "https://resizing.flixster.com/7b948xu-X_sRms81mbdeptbpphU=/206x305/v2/https://resizing.flixster.com/-O0zsK2XE6LhZusJQTS4FeQ4mpM=/ems.ZW1zLXByZC1hc3NldHMvdHZzZXJpZXMvUlRUVjI3OTE4NC53ZWJw",
                        "img_alt" => "poster Altered carbon",
                        "title" => "ALTERED CARBON",
                        "desc" => "More than 300 years in the future, society has been
                        transformed by new technology, leading to human
                        bodies being interchangeable and death no longer
                        being permanent",
                        "permalink" => "movie-2.php",
                        
                    ),
                    "movie3" => array(
                        "img_src" => "https://resizing.flixster.com/KPTgMb_br_6m-_nLMcRfvoU6doU=/206x305/v2/https://resizing.flixster.com/VFKUngWfCPVupHuvo8RcriHbNYY=/ems.ZW1zLXByZC1hc3NldHMvdHZzZXJpZXMvUlRUVjQzOTcyNy53ZWJw",
                        "img_alt" => "poster After life",
                        "title" => "AFTER LIFE",
                        "desc" => "Tony had a perfect life -- until his wife Lisa died.
                        After that tragic event, the formerly nice guy
                        changed",
                        "permalink" => "movie-3.php",
                        
                    ),
                );

                $i = 1;

                foreach ($movies as $movie){
                    ?>
                    <div class="card" id = "<?php echo $i ?>">
                        <img
                            src="<?php echo $movie["img_src"]; ?>"
                            class="card-img-top"
                            alt="<?php echo $movie["img_alt"]; ?>"
                        />
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $movie["title"]; ?></h5>
                            <p class="card-text"><?php echo $movie["desc"] . " ..."; ?></p>
                            <a href="<?php echo $movie["permalink"]; ?>" class="btn btn-primary"
                                >Read more</a
                            >
                        </div>
                    </div>

                    <?php
                    $i++;
                }

                ?>
            </div>
        </div>
        <div class="footer">Copyright, toate drepturile rezervate</div>
        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ"
            crossorigin="anonymous"
        ></script>
    </body>
</html>
