<?php require_once('includes/header.php'); ?>

        <div class="container">
            <h1>Flying the Feathered Edge: The Bob Hoover Project</h1>
            <div class="row">
            <div class="col-md-4 col-lg-3">
                    <img class="card-img-top"
                        src="https://resizing.flixster.com/XxZbMOe_D6ibhWckBo9fdzDm6dM=/206x305/v2/https://resizing.flixster.com/lCl7FMgE_MHzqQDvDGVapBugkYY=/ems.ZW1zLXByZC1hc3NldHMvbW92aWVzL2MwMjlmZWYyLTMwOWMtNDIyNy04OTAzLTViYjBkMWEwZjgxMS5qcGc="
                        alt="poster Flying the Feathered Edge: The Bob Hoover Project"
                    />
                </div>
                <div class="col-md-8 col-lg-9">
                    <p><strong>2014</strong></p>
                    <div class="mb-3"><strong>Runtime: </strong><?php echo runtime_prettier ($movies["2"]["runtime"]); ?></div>
                    <div class="mb-3"><strong>Genre: </strong>Biography, Documentary</div>
                    <div class="description mb-3">
                    A unique look at flying from Bob Hoover, a founding father of modern aerobatics. Too tall, with poor eyesight and an acute case of air sickness, Bob went on to become a fighter pilot, test pilot, air show pilot, and one of the best who ever lived. Harrison Ford, Carroll Shelby, and other aerospace legends bring Bob's incredible story into the limelight.
                    </div>
                    <div class="mb-3"><strong>Producers: </strong>Kimberley Furst, Mark McPherson
                    </div>
                    <div class="mb-3"><strong>Director: </strong>Kimberley Furst</div>
                </div>
            </div>
        </div>
<?php require_once("includes/footer.php"); ?>
