<?php require_once('includes/header.php'); ?>

        <div class="container">
            <h1>The Cleaner</h1>
            <div class="row">
            <div class="col-md-4 col-lg-3">
                    <img class="card-img-top"
                        src="https://resizing.flixster.com/33ZR-CFOek8Y8zFX2L485pVGaMg=/206x305/v2/https://resizing.flixster.com/kS1oWUWGR0qTZjkRbveneG4yADM=/ems.ZW1zLXByZC1hc3NldHMvbW92aWVzLzE3MTA1ZmFkLTE4MzAtNDQ3Ny05ZWQ3LTE1ZGZmYjNjYmI2ZS5qcGc="
                        alt="poster Black Widow"
                    />
                </div>
                <div class="col-md-8 col-lg-9">
                    <div class="h3">2021</div>
                    <div class="mb-3"><strong>Runtime: </strong><?php echo runtime_prettier ($movies["1"]["runtime"]); ?></div>
                    <div class="mb-3"><strong>Genre: </strong>Drama, Crime, Mystery & Thriller</div>
                    <div class="descrition mb-3">
                    A middle-aged house cleaner gets caught up in a violent crime after being hired to locate a client's estranged son.
                    </div>
                    <div class="mb-3">
                        <strong>Producers: </strong>John W. Bosher, Chris Charles, Faust Checho, Kate Grady
                    </div>
                    <div class="mb-3"><strong>Director: </strong>Erin Elders</div>
                </div>
            </div>
        </div>

<?php require_once("includes/footer.php"); ?>
